<?php
require "connection.php";
$query="select* from student";
$result=mysqli_query($con,$query);

if(isset($_GET["msg"]))
{
    $ms=$_GET["msg"];
    echo "<script>alert('$ms')</script>";
}
?>
<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
<form method="post" action="create.php">
    <table>
        <tr><td><label>Enter Id</label></td><td><input type="number"  name="id"></td></tr>

        <tr><td><label>Enter Name</label></td><td><input type="text"  name="name"></td></tr>
        
        <tr><td><label>Enter Email</label></td><td><input type="email"  name="email"></td></tr>
        
        <tr><td><label>Enter course</label></td><td><input type="text"  name="course"></td></tr>
        
        <tr><td><label>Enter Fee</label></td><td><input type="number"  name="fee"></td></tr>
        
        <tr><td></td><td><input type="submit" value="Save Student" name="sub"></td></tr>
        
    </table>
</form>

<table>
    <tr><th>Id</th><th>Name</th><th>Email</th><th>Course</th><th>Fee</th><th>Delete</th></tr>
    <?php
while($row=mysqli_fetch_assoc($result))
{
echo "<tr><td>".$row["id"]."</td><td>".$row["name"]."</td><td>".$row["email"]."</td><td>".$row["course"]."</td><td>".$row["fee"]."</td><td><a href=Delete.php?id=".$row["id"].">Delete</a></td></tr>";
}
 
    ?>

</table>
</body>
</html>