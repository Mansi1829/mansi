<?php

require "connection.php";
$id=$_POST["id"];
$name=$_POST["name"];
$email=$_POST["email"];
$course=$_POST["course"];
$fee=$_POST["fee"];

print_r($_POST);

$query="insert into student (id,name,email,course,fee) values('".$id."','".$name."','".$email."','".$course."','".$fee."')";

$result=mysqli_query($con,$query);
if($result)
{
	header('location:index.php?msg=Record created successfully');
}
else
{
	header('location:index.php?msg=Record not  created successfully');
}


?>