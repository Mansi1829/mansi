<?php

$host="localhost";
$user="root";
$pass="";
$db="man";
$con=mysqli_connect($host,$user,$pass,$db);

?>