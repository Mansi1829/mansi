<?php
require "connection.php";
$id=$_GET["id"];
$query="delete from student where id=$id";
$result=mysqli_query($con,$query);
if($result)
{
	header('location:index.php?msg=Record deleted successfully');
}
else
{
	//header('location:index.php?msg=Record not  deleted successfully');

}
mysqli_error($result);

?>