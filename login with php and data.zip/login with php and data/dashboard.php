<?php
require "connection.php";
session_start();


if(!isset(($_SESSION["login"])))
{
	header("location:index.php");
}
else
{

$userid=$_SESSION["login"];

$query="select* from admin where loginid='".$userid."'";

$result=mysqli_query($cnn,$query);
$cap=mysqli_fetch_assoc($result);
}


?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<?php
	include_once"stylish.php";
	?>
</head>
<body>
	<div class="page-header">
        <?php
        echo($cap["name"]) ;

        ?>
        	
        </b>. Welcome to our site.</h1>
    </div>
	<a href="logout.php" style="float:right;" class="btn btn-warning">Logout</a>
	

</body>
</html>