<!DOCTYPE html>
<html>
<head>
	<?php
	include"stylish.php";
	?>
	<style type="text/css">
		.card{
			padding:20px;
			margin-top: 100px;
			box-shadow: 12px 12px 12px blue }
	</style>
	
</head>
<body>
	<div class="row">
		<div class="col-6 offset-3">
	<div class="card">
	<form method="post" action="login.php">
		<div class="form-group">
			<?php
			if(isset($_GET["error"]))
			{
				echo$_GET["error"];
			}
			?>
		</div>
		<div class="form-group">
			<label>Username</label>
			<input type="text" name="userid" class="form-control" placeholder="Enter username">
		</div>
		<div class="form-group">
			<label>Password</label>
			<input type="password" name="pass" class="form-control" placeholder="Enter password">
		</div>
		<div class="form-group">
			<input type="submit" name="" class="btn btn-primary" value="Login">
		</div>
		
	</form>
	</div>
	</div>



</body>
</html>