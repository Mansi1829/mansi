<?php

$host="localhost";
$user="root";
$password="";
$dbname="gracedb";
$cnn=mysqli_connect($host,$user,$password,$dbname);

?>