<?php

require "connection.php";
if(isset($_POST))
{
  session_start();
  $userid=$_POST["userid"];
  $pass=$_POST["pass"];

$query="select count(*) as user from admin where loginid='".$userid."' and password='".$pass."'";
$result=mysqli_query($cnn,$query);
$row=mysqli_fetch_assoc($result);


  if($row["user"]==1)
  {
    $_SESSION["login"]=$userid;
    $_SESSION["time"]=time();
   header("location:dashboard.php");
  }
  else
  {
     header("location:index.php?error=Invalid login id or password");
  }
}
?>