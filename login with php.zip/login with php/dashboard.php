<?php
session_start();
if(!isset(($_SESSION["login"])))
{
	header("location:index.php");
}
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<?php
	include_once"stylish.php";
	?>
</head>
<body>
	<h1>Welcome to noida</h1>
	<a href="logout.php" class="btn btn-warning">Logout</a>

</body>
</html>