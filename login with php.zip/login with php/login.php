<?php
if(isset($_POST))
{
  session_start();
  $userid=$_POST["userid"];
  $pass=$_POST["pass"];
  if($userid=="admin"&& $pass=="123")
  {
    $_SESSION["login"]=$userid;
    $_SESSION["time"]=time();
    header("location:dashboard.php");
  }
  else
  {
     header("location:index.php?error=Invalid login id or password");
  }
}
?>